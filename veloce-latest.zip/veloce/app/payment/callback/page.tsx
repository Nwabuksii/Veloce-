"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export default function PaymentCallbackPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [status, setStatus] = useState("Verifying your payment...");

  useEffect(() => {
    const reference = params.get("reference") || params.get("trxref");

    if (!reference) {
      setStatus("Missing payment reference — if you were charged, contact support.");
      return;
    }

    fetch("/api/payments/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reference }),
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Verification failed");
        setStatus("Payment confirmed — unlocking your block...");
        setTimeout(() => router.push("/dashboard"), 1200);
      })
      .catch((err) => setStatus(err.message));
  }, [params, router]);

  return (
    <div className="auth-page">
      <div className="auth-card" style={{ textAlign: "center" }}>
        <h1>
          Veloce <span className="accent">.</span>
        </h1>
        <p className="auth-sub">{status}</p>
      </div>
    </div>
  );
}
