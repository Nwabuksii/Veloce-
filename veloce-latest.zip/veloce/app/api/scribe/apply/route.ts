import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/session";

// Any logged-in Student (or higher) can submit a scribe application.
// requireRole("STUDENT") just means "must be authenticated" since
// Student is the lowest rung — Scribes and Admins pass this check too.
export const POST = requireRole("STUDENT", async (req: NextRequest, user) => {
  const existing = await prisma.scribeApplication.findUnique({
    where: { userId: user.sub },
  });

  if (existing) {
    return NextResponse.json({ error: "You've already applied", status: existing.status }, { status: 409 });
  }

  const application = await prisma.scribeApplication.create({
    data: { userId: user.sub, status: "PENDING" },
  });

  return NextResponse.json({ application });
});
