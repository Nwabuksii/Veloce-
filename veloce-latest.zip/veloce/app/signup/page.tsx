"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { saveUser } from "@/lib/client-session";

// Fixed to "babcock" for now — this is a single-campus pilot.
// Once other universities go live, this becomes a dropdown.
const UNIVERSITY_SLUG = "babcock";

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email, password, universitySlug: UNIVERSITY_SLUG }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error?.formErrors?.[0] || data.error || "Signup failed");
        return;
      }

      saveUser(data.user);
      router.push("/dashboard");
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>
          Veloce <span className="accent">.</span>
        </h1>
        <p className="auth-sub">Create your Babcock student account</p>

        <form onSubmit={handleSubmit}>
          <label>
            Full name
            <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          </label>
          <label>
            Email
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              minLength={8}
              required
            />
          </label>

          {error && <div className="auth-error">{error}</div>}

          <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
            {loading ? "Creating account..." : "Sign up"}
          </button>
        </form>

        <p className="auth-switch">
          Already have an account? <a href="/login">Log in</a>
        </p>
      </div>
    </div>
  );
}
