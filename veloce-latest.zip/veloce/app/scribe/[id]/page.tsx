"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { getStoredUser } from "@/lib/client-session";

interface ProfileBlock {
  noteId: string;
  blockTitle: string;
  courseCode: string;
  courseName: string;
  price: number;
}

interface Profile {
  id: string;
  fullName: string;
  joinedAt: string;
  isActiveScribe: boolean;
  paidSubscriberCount: number;
  followerCount: number;
  totalSales: number;
  avgRating: number | null;
  ratingCount: number;
  trustLevel: "NEW" | "RISING" | "TRUSTED" | "ELITE";
  trustLabel: string;
  isFollowing: boolean;
  isSelf: boolean;
  blocks: ProfileBlock[];
}

const TRUST_STYLES: Record<Profile["trustLevel"], { bg: string; color: string }> = {
  NEW: { bg: "#eef3fa", color: "#5e7188" },
  RISING: { bg: "#fdf3e3", color: "#a5690a" },
  TRUSTED: { bg: "#e7f6ec", color: "#1b7e4a" },
  ELITE: { bg: "#f0e9fb", color: "#6b3fa0" },
};

export default function ScribeProfilePage() {
  const router = useRouter();
  const params = useParams();
  const scribeId = params.id as string;

  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [followLoading, setFollowLoading] = useState(false);

  useEffect(() => {
    const user = getStoredUser();
    if (!user) {
      router.push("/login");
      return;
    }

    fetch(`/api/scribe/${scribeId}/profile`)
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to load profile");
        setProfile(data.profile);
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Something went wrong"))
      .finally(() => setLoading(false));
  }, [router, scribeId]);

  async function toggleFollow() {
    if (!profile) return;
    setFollowLoading(true);
    try {
      const res = await fetch(`/api/scribe/${scribeId}/follow`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not update follow status");

      setProfile((prev) => (prev ? { ...prev, isFollowing: data.following, followerCount: data.followerCount } : prev));
    } catch (err) {
      alert(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setFollowLoading(false);
    }
  }

  return (
    <div className="page-wrap">
      <div className="app-container" style={{ maxWidth: 720 }}>
        <div className="top-bar">
          <div className="logo">
            <h1>
              Veloce <span className="accent">.</span>
            </h1>
            <div className="logo-sub">Scribe profile</div>
          </div>
          <button className="btn" onClick={() => router.back()}>
            <i className="fas fa-arrow-left"></i> Back
          </button>
        </div>

        {loading && <p style={{ marginTop: "1rem", color: "#5e7188" }}>Loading profile...</p>}
        {error && <div className="auth-error" style={{ marginTop: "1rem" }}>{error}</div>}

        {profile && (
          <div style={{ marginTop: "1.5rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "1rem" }}>
              <div>
                <h2 style={{ fontSize: "1.5rem" }}>{profile.fullName}</h2>
                <span
                  style={{
                    display: "inline-block",
                    marginTop: "0.4rem",
                    background: TRUST_STYLES[profile.trustLevel].bg,
                    color: TRUST_STYLES[profile.trustLevel].color,
                    padding: "0.25rem 0.9rem",
                    borderRadius: "30px",
                    fontSize: "0.8rem",
                    fontWeight: 600,
                  }}
                >
                  <i className="fas fa-shield-alt"></i> {profile.trustLabel}
                </span>
                {!profile.isActiveScribe && (
                  <span
                    style={{
                      display: "inline-block",
                      marginTop: "0.4rem",
                      marginLeft: "0.5rem",
                      background: "#fdecec",
                      color: "#b13e3e",
                      padding: "0.25rem 0.9rem",
                      borderRadius: "30px",
                      fontSize: "0.8rem",
                      fontWeight: 600,
                    }}
                  >
                    No longer an active scribe
                  </span>
                )}
              </div>

              {!profile.isSelf && profile.isActiveScribe && (
                <button
                  className={`btn ${profile.isFollowing ? "" : "btn-primary"}`}
                  onClick={toggleFollow}
                  disabled={followLoading}
                >
                  <i className={`fas ${profile.isFollowing ? "fa-user-check" : "fa-user-plus"}`}></i>{" "}
                  {profile.isFollowing ? "Following" : "Follow"}
                </button>
              )}
            </div>

            <div style={{ display: "flex", gap: "1rem", margin: "1.2rem 0", flexWrap: "wrap" }}>
              <div className="role-pill">
                <i className="fas fa-shopping-cart"></i> {profile.paidSubscriberCount} paid subscriber
                {profile.paidSubscriberCount === 1 ? "" : "s"}
              </div>
              <div className="role-pill">
                <i className="fas fa-users"></i> {profile.followerCount} follower{profile.followerCount === 1 ? "" : "s"}
              </div>
              <div className="role-pill">
                <i className="fas fa-star" style={{ color: "#e0a63e" }}></i>{" "}
                {profile.avgRating != null ? `${profile.avgRating.toFixed(1)} (${profile.ratingCount})` : "No ratings yet"}
              </div>
            </div>

            <h3 style={{ marginTop: "1.5rem", fontSize: "1.1rem" }}>
              <i className="fas fa-layer-group" style={{ color: "#2a7de1" }}></i> Live blocks
            </h3>

            {profile.blocks.length === 0 && (
              <p style={{ color: "#5e7188", marginTop: "0.6rem" }}>No live blocks yet.</p>
            )}

            <div className="card-grid" style={{ marginTop: "0.8rem" }}>
              {profile.blocks.map((b) => (
                <div key={b.noteId} className="block-card">
                  <div className="badge">{b.courseCode}</div>
                  <h3>{b.blockTitle}</h3>
                  <div className="meta">{b.courseName}</div>
                  <span className="price-tag">₦{b.price.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
