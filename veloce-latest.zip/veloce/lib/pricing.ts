// Flat discount for students who requested a block that later got fulfilled
// by a scribe. Founder confirmed 10% as the default — bump this (or make it
// per-request) if they want it configurable later.
export const REQUEST_FULFILLED_DISCOUNT = 0.1;

export function applyRequestDiscount(price: number): number {
  return Math.round(price * (1 - REQUEST_FULFILLED_DISCOUNT));
}
